#' @title Instala e checa os cosigos da curadoria
#' @name bay_max
#'
#' @description Instala pacotes padoes da curadoria 
#'
#' @return apply packt
#'
#' @param outros string
#' @author Jonatas Ribeiro
#' @importFromutils install.packages
#' @export

bay_max <- function(outros = F){

  pkg <- c("tryCatchLog","httr","jsonlite","RPostgreSQL",
           "RODBC","reshape","readbulk","plotly","lubridate",
           "readxl","HH","sqldf","dplyr","data.table","arules",
           "dgof","pROC","Information","InformationValue","stringr",
           "tree","rpart","Amelia","ggplot2","descr","scales",
           "ggthemes","ztable","tibble","tidyr","RCurl","purrr","randomForest",
           "rstudioapi","getopt","readxlsb","RMySQL","openxlsx","RPostgres")
  
  if (outros != F) {
    pkg <- c(pkg,outros)  
  }
  novo.pkg <- pkg[!(pkg %in% utils::installed.packages()[, "Package"])]
  if (length(novo.pkg)) {
    utils::install.packages(novo.pkg, dependencies = TRUE)
  }
  x <- sapply(pkg, require, character.only = TRUE)
  if (length(x[(x == F)])) {
    print(x[(x != T)])
  }
{

print("                                      :##@##!     ")
print("                  .::!!!:.         :@:        ##  ")
print("             :@#.          .#@:  .@:           ## ")
print("           ##                 :@!@.            ## ")
print("          #!   .#. .:: ..#.    #:             !#  ")
print("          #!                  !.            .@:   ")
print("           !@.            .#.  !:         !@:     ")
print("         !@!.!.  .::.      ...  :!    .#@:        ")
print("      .@!   # .           .  ... .@@#.            ")
print("    .@:.   !.......            : .##              ")
print("   ##    !:  .                     :@.            ")
print("  #!.   !  .                      .. ##           ")
print(" !#    #                              #!          ")
print(".#!    !                              !#          ")
print(" #!    .!                            .@.          ")
print(" !#.     !:                         ##            ")
print("  :@.     ! :#.                 .#..@!            ")
print("    .#@###@: .    .:::!#!:::.     .!@.            ")
print("          .@:         .@#         !@:             ")
print("            :@!      .@:@#.    :#@:               ")
print("                :###!.    .!!!.                   ")
print("             :         BAYMAX        :            ")

}
}