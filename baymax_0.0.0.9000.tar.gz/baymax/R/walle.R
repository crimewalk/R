#' @title salvador de erros do seu codigo Curadoria
#' @name wall.e
#'
#' @description Salva o erro do cod
#'
#' @return Error
#' 
#' @param x A string
#'
#' @author Jonatas Ribeiro
#' @importtryCatchLog tryLog
#' @importFromjsonlite fromJSON, toJSON
#' @importFromhttr POST, add_headers
#' @importFromdata.table as.ITime
#' @importFromutils write.csv
#' @importFrombase list, as.character,paste0,gsub
#' @importFrombaymax cod_name, client_shrp
#' @importFromtryCatchLog tryLog
#' @importFromstringr str_extract
#' @importFromrstudioapi getSourceEditorContext
#' 
#' @export
#' 

wall.e <- function(x){
{
print("                    ..:.   .:...                    ")
print("               ..:::::::.  :::::::..                ")
print("            .:::     :::::::.:      :::.            ")
print("          .::.:        ::: ::        ::::           ")
print("         .::..:      :  :: :      :: :.:::          ")
print("       . .:....        :   ::      ::...::  .       ")
print("       . .:.....::  ::::   :.:    ::....:: .:       ")
print("       .:. :........::.::: ::.::........: .:.       ")
print("        .:. :::::::.   :::::.   .::::::: .::.       ")
print("          .:.......    :::::.      ......::         ")
print("             .......  .::::::   ........            ")
print("            .::::..   .:: :::    ..::::.            ")
print("        ...::::.      .:    :      .::...:.         ")
print("        ...::::.       WALL-E      .::...:.         ")
}
  api <- baymax::client_shrp("https://paschoalotto.sharepoint.com/sites/CuradoriaPlus")
  name = base::as.character(baymax::cod_name())
  alt = tryCatch({x}, 
                 error = function(erro) {
                   paste0(name,' ','Error: ',erro[1])
                 }
                 # ,warning= function(warn) {
                 #   paste0(name,' ','Warning: ',warn[1])
                 # }
  )
  
  iff = read.table(text = name, sep = "_", col.names = F)
  msg = gsub(paste0(name,' Error: '),'',ifelse(substring(alt, 1,nchar(paste0(name,' '))) == paste0(name,' '),alt,"NULL"))
  
  if (as.character(name) != "NULL" & as.character(msg[1]) != "NULL") {
    mt = jsonlite::fromJSON(base::as.character(httr::POST(
      url = "https://paschoalotto.sharepoint.com/sites/CuradoriaPlus/_api/web/lists/getbytitle('db_server[walle]')/Items",
      httr::add_headers("Authorization" = 
                          base::paste0("Bearer ",
                                       jsonlite::fromJSON(as.character(httr::POST(
                                         url = "https://accounts.accesscontrol.windows.net/1de5ae7d-2e25-49b4-b8c0-e28ffe53080a/tokens/OAuth/2",
                                         httr::add_headers("Content-Type" = "application/x-www-form-urlencoded"),
                                         body = base::list("grant_type" = " client_credentials",
                                                           "client_id" = api$client_id,
                                                           "client_secret" = api$client_secret,
                                                           "resource" = api$resource),
                                         encode = "form")))$access_token),
                        "Content-Type" = "application/json",
                        "Accept" = "application/json;odata=verbose"),
      body = jsonlite::toJSON(base::list(Title = iff$FALSE.[1],
                                         name = gsub(paste0(iff$FALSE.[1],'_'),'',name),
                                         err = msg),
                              pretty = TRUE, auto_unbox = TRUE),
      encode = "form")))
  }
}
