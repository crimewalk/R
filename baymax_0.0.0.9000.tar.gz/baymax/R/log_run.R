#' @title Log de execucao da Curadoria
#' @name log_run
#'
#' @description Envia via API do Sharepoint um log para a lista
#'               db_server/log_run/
#'
#' @return POST LOG JSON
#' 
#' @param end A string
#'
#' @author Jonatas Ribeiro
#' @importFromjsonlite fromJSON, toJSON
#' @importFromhttr POST, add_headers
#' @importFromdata.table as.ITime
#' @importFrombaymax cod_name, client_shrp
#' @importFromstringr str_extract
#' @importFromrstudioapi getSourceEditorContext
#' @importFromgetopt, get_Rscript_filename
#' @importFromrstudioapi, getSourceEditorContext
#' 
#' @export
#' 
log_run <- function(end){
    
    api <- baymax::client_shrp("https://paschoalotto.sharepoint.com/sites/CuradoriaPlus")
    name = as.character(baymax::cod_name())
    iff = read.table(text = name, sep = "_", col.names = F)
    mt <- jsonlite::fromJSON(as.character(httr::POST(
        url = "https://paschoalotto.sharepoint.com/sites/CuradoriaPlus/_api/web/lists/getbytitle('db_server[log_run]')/Items",
        httr::add_headers("Authorization" = 
                              base::paste0("Bearer ",
                                           jsonlite::fromJSON(as.character(httr::POST(
                                               url = "https://accounts.accesscontrol.windows.net/1de5ae7d-2e25-49b4-b8c0-e28ffe53080a/tokens/OAuth/2",
                                               httr::add_headers("Content-Type" = "application/x-www-form-urlencoded"),
                                               body = base::list("grant_type" = " client_credentials",
                                                                 "client_id" = api$client_id,
                                                                 "client_secret" = api$client_secret,
                                                                 "resource" = api$resource),
                                               encode = "form")))$access_token),
                          "Content-Type" = "application/json",
                          "Accept" = "application/json;odata=verbose"),
        body = jsonlite::toJSON(list(Title = iff$FALSE.[1],
                                     name = gsub(paste0(iff$FALSE.[1],'_'),'',name),
                                     Inicio = paste0(as.Date(end),"T",data.table::as.ITime(end),'Z'),
                                     fim = paste0(Sys.Date(),"T",data.table::as.ITime(Sys.time()),'Z')),
                                pretty = TRUE, auto_unbox = TRUE),
        encode = "form")))
}
