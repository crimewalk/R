#' @title Arrume seu cpf/cnpj
#' @name cpf_cnpj
#'
#' @description Arruma seu cpf e cnpj para o padrao
#'
#' @param x as character
#' 
#' @return cpf/cnpj padrao 11/14 dig com zero na frente
#'
#' @author Jonatas Ribeiro
#' @importbase ifelse, nchar, as.character, paste0, substr, gsub
#' @export

cpf_cnpj <- function(x){
x = base::gsub("[^0-9]", "",base::as.character(x))
  base::ifelse(
  base::nchar(base::as.character(x)) > 11,
  base::substr(
    base::paste0('00000000000',base::as.character(x)),
    base::nchar(base::paste0('00000000000',base::as.character(x)))-13,
    base::nchar(base::paste0('00000000000',base::as.character(x)))
    ),
  base::substr(
    base::paste0('00000000000',base::as.character(x)),
    base::nchar(base::paste0('00000000000',base::as.character(x)))-10,
    nchar(paste0('00000000000',base::as.character(x)))
    )
  )
}
