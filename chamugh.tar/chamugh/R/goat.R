#' @title Data automatica Curadoria
#' @name goat
#'
#' @description Caso seja enviado alguma solicitacao via goat, retorna data desejada
#'
#' @return data de execucao
#' 
#' @param x A string
#' @param y A string
#' @param manual A string
#' @param dom A string
#' @param sab A string
#' @param feriados A string
#'
#' @author Jonatas Ribeiro
#' @importtryCatchLog tryLog
#' @importFromjsonlite fromJSON, toJSON
#' @importFromhttr POST, add_headers, GET
#' @importFromdata.table as.IDate, wday
#' @importFrombase list, as.character,paste0,gsub, data.frame, substr, weekdays, exists, months
#' @importFromchamugh cod_name, client_shrp
#' @importFromlubridate ymd_hms, floor_date
#' @importFromdplyr filter, mutate
#' @importFromstringr str_extract, str_match_all
#' @importFromrstudioapi getSourceEditorContext
#' 
#' @export
#' 

goat <- function(x = 2,y = 1,manual = FALSE,dom = TRUE,sab = TRUE,feriados = FALSE,ant = 1){
  {

print(" ⠀⠠⠴⠶⠾⠿⠿⠿⢶⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⢿⣿⣆⠐⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠿⠿⠆⠹⠦⠀⠀⠀⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣀⠐⣶⣶⣶⣶⣶⣶⡀⢀⣀⣀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⢿⣿⡆⢹⡿⠻⢿⣿⣿⣷⠈⠿⠛⠁⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣾⣷⣤⣉⣠⣾⣷⣦⣼⣿⣿⣿⣧⠀⠀⠀⠀⠀")
print("⠀⣶⣶⣶⣶⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀")
print("⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀")
print("⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣛⠻⢧⣘⡷⠀⠀⠀")
print("⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⣉⠛⠿⣷⣦⣌⠁⠀⠀⠀")
print("⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣠⠘⠀⠀⢹⣿⣶⣶⠀⠀⠀⠀⠀⠀")
print("⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⢺⣿⠀⠀⠀⠘⣿⣿⡟⠀⠀⠀⠀⠀⠀")
print("⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠁⠀⠀⠀⠀⠻⡟⠃⠀⠀⠀⠀⠀⠀")
print("⠀⠛⠛⠛⠛⠛⠛⠛⠛⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀")
print("             :         GC THE GOAT        :            ")
}
  # x = 2
  # y = 1
  # manual = FALSE
  # dom = TRUE
  # sab = TRUE
  # feriados = FALSE
  # ant = 1
  api <- chamugh::client_shrp("https://paschoalotto.sharepoint.com/sites/CuradoriaPlus")
  name <- NULL
  try(name <- chamugh::cod_name())
  if(!is.null(name)){
    try(cod <- data.frame(stringr::str_match_all(name,'(.*?)_'))[1,2])
    if (is.na(cod)) {
      cod = name
    }
  }
  obs <- NA
  out.day <- c('-01-01','-04-21','-05-01','-09-07','-10-12','-11-02','-11-15','-12-25')
  xt <- base::data.frame()
  mt <- NULL
  if (exists('cod')) {
    try(mt <- jsonlite::fromJSON(base::as.character(httr::GET(
      url = paste0("https://paschoalotto.sharepoint.com/sites/CuradoriaPlus/_api/web/lists/getbytitle('db_goat[date]')/Items?$filter= Title eq '", cod,"'"),
      httr::add_headers("Authorization" = 
                          base::paste0("Bearer ",
                                       jsonlite::fromJSON(as.character(httr::POST(
                                         url = "https://accounts.accesscontrol.windows.net/1de5ae7d-2e25-49b4-b8c0-e28ffe53080a/tokens/OAuth/2",
                                         httr::add_headers("Content-Type" = "application/x-www-form-urlencoded"),
                                         body = base::list("grant_type" = " client_credentials",
                                                           "client_id" = api$client_id,
                                                           "client_secret" = api$client_secret,
                                                           "resource" = api$resource),
                                         encode = "form")))$access_token),
                        "Accept" = "application/json;odata=verbose"),encode = "form"))))
  }
  if (!is.null(mt$d$results$Title)) {
    try(xt <- dplyr::filter(base::data.frame(mt$d$results$Title,mt$d$results$script,mt$d$results$data,mt$d$results$ID,mt$d$results$Created,mt$d$results$obs),
                            paste0(mt.d.results.Title,"_",mt.d.results.script) == name)[1,])
  }
  if (length(xt) > 0) {
    try(xt <- dplyr::filter(xt, paste0(mt.d.results.Title,"_",mt.d.results.script) == c(name)))
  }
  
  tt <- data.table::as.IDate(ifelse(data.table::wday(Sys.Date()) == 2,Sys.Date()-x,Sys.Date()-y))
  
  if (feriados == TRUE) {
    tt <- data.table::as.IDate(ifelse(tt %in% c(base::as.Date(paste0(substring(tt,1,4),out.day))),tt-1,tt))
  }
  
  if (dom == FALSE) {
    tt <- data.table::as.IDate(ifelse(data.table::wday(tt) == 1,tt-1,tt))
  }
  
  if (sab == FALSE) {
    tt <- data.table::as.IDate(ifelse(data.table::wday(tt) == 7,tt-1,tt))
  }
  
  
  if (!manual %in% c(NULL,"",FALSE)) {
    tt <- data.table::as.IDate(manual)
    
    if (feriados == FALSE) {
      tt <- data.table::as.IDate(ifelse(tt %in% c(base::as.Date(paste0(substring(tt,1,4),out.day))),tt-1,tt))
    }
    
    if (dom == FALSE) {
      tt <- data.table::as.IDate(ifelse(data.table::wday(tt) == 1,tt-1,tt))
    }
    
    if (sab == FALSE) {
      tt <- data.table::as.IDate(ifelse(data.table::wday(tt) == 7,tt-1,tt))
    }
    
    
  } else if (nrow(xt) > 0) {
    
    try(xt  <- dplyr::filter(xt, lubridate::ymd_hms(mt.d.results.Created) == c(min(lubridate::ymd_hms(mt.d.results.Created)))))
    tt <- data.table::as.IDate(xt$mt.d.results.data)
    try(obs <- xt$mt.d.results.obs)
    try(del <- jsonlite::fromJSON(base::as.character(httr::POST(
      url = paste0("https://paschoalotto.sharepoint.com/sites/CuradoriaPlus/_api/web/lists/getbytitle('db_goat[date]')/Items(",
                   xt$mt.d.results.ID,")"),
      httr::add_headers("Authorization" =
                          base::paste0("Bearer ",jsonlite::fromJSON(as.character(httr::POST(
                            url = "https://accounts.accesscontrol.windows.net/1de5ae7d-2e25-49b4-b8c0-e28ffe53080a/tokens/OAuth/2",
                            httr::add_headers("Content-Type" = "application/x-www-form-urlencoded"),
                            body = base::list("grant_type" = " client_credentials",
                                              "client_id" = api$client_id,
                                              "client_secret" = api$client_secret,
                                              "resource" = api$resource),
                            encode = "form")))$access_token),
                        "Accept" = "application/json;odata=verbose",
                        "Content-Type" = "application/json",
                        "X-HTTP-Method" = "DELETE",
                        "If-Match" = "*"),encode = "form"))))
  } 
  
  ano <- base::substr(tt, 1, 4)
  mes <- base::substr(tt, 6, 7)
  dia <- base::substr(tt, 9, 10)
  inicio <- base::paste0(ano,"-",mes,"-","01")
  fim <- base::paste0(ano,"-",mes,"-",dia)
  unida.inicio <- base::paste0(ano,mes,"01")
  unida.fim <- base::paste0(ano,mes,dia)
  api.inicio <- base::paste0(base::as.Date(inicio),"T00:00:00Z")
  api.fim <- base::paste0(base::as.Date(fim),"T00:00:00Z")
  ptbr.inicio <- base::paste0("01","/",mes,"/",ano)
  ptbr.fim <- base::paste0(dia,"/",mes,"/",ano)
  dir.mes <- base::paste0(mes," - ",base::months(base::as.Date(inicio)))
  dir.mes2 <- base::paste0(mes," . ",base::months(base::as.Date(inicio)))
  name.day <- base::weekdays(base::as.Date(fim))
  nome.mes <- base::months(base::as.Date(fim))
  last.day <- as.Date(lubridate::floor_date(as.Date(inicio) %m+% base::months(1), 'month')-1)
  table.d <- base::data.frame(list(as.Date(inicio):as.Date(fim)))
  colnames(table.d) <- 'datas'
  du <- dplyr::filter(dplyr::mutate(table.d,
                                    Datas = data.table::as.IDate(datas),
                                    d = ifelse(data.table::wday(Datas) %in% c(1,7),0,1),
                                    d = ifelse(Datas %in% c(base::as.Date(paste0(substring(inicio,1,4),out.day))),0,d),
                                    du = cumsum(d)),Datas == fim)$du
  inicio.ant = as.Date(lubridate::floor_date(as.Date(last.day) %m+% base::months(-ant), 'month'))
  ultd.ant = as.Date(lubridate::floor_date(as.Date(last.day) %m+% base::months(-(ant-1)), 'month')-1)
  
  base::data.frame(inicio,fim,last.day,unida.inicio,unida.fim,api.inicio,api.fim,ptbr.inicio,ptbr.fim,dir.mes,dir.mes2,ano,mes,dia,du,name.day,nome.mes,obs,inicio.ant,ultd.ant)

  }