#' @title Traz o nome do script
#' @name cod_name
#'
#' @description Funcao pega o nome do script
#'
#' @return Name of script
#'
#' @author Jonatas Ribeiro
#' 
#' @importFromgetopt, get_Rscript_filename
#' @importFromrstudioapi, getSourceEditorContext
#' @importFrombase, normalizePath
#' @importFromutils, read.table
#' @importFromstringr, str_extract
#' 
#' @export

cod_name <- function(){
  
  rscript = tryCatch({as.character(getopt::get_Rscript_filename())}, 
                     error = function(erro) {
                       paste0(NA)
                     },
                     warning= function(warn) {
                       paste0(NA)
                     })
  
  rstudio = tryCatch({as.character(rstudioapi::getSourceEditorContext()$path)}, 
                     error = function(erro) {
                       paste0(NA)
                     },
                     warning= function(warn) {
                       paste0(NA)
                     })
  
  if (!is.na(rscript)) {
    rscript <- base::normalizePath(rscript,winslash = '/')
    nome = utils::read.table(text =  rscript,sep = '/', col.names = F)
  } else if (!is.na(rstudio)) {
    nome = utils::read.table(text =  rstudio,sep = '/', col.names = F)
  }
  
  if (nrow(nome)>0) {
    if (length(is.na(stringr::str_extract(nome$FALSE., "(.*?)\\.R"))[!is.na(stringr::str_extract(nome$FALSE., "(.*?)\\.R"))]) > 0) {
      gsub("\\.R","",stringr::str_extract(nome$FALSE., "(.*?)\\.R")[!is.na(stringr::str_extract(nome$FALSE., "(.*?)\\.R"))])
    } else if (length(is.na(stringr::str_extract(nome$FALSE., "(.*?)\\.r"))[!is.na(stringr::str_extract(nome$FALSE., "(.*?)\\.r"))]) > 0) {
      gsub("\\.r","",stringr::str_extract(nome$FALSE., "(.*?)\\.r")[!is.na(stringr::str_extract(nome$FALSE., "(.*?)\\.r"))])
    } else  {
      NULL
    }
  } else {
    NULL
  }
}