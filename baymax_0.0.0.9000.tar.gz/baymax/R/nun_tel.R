#' @title Arrume seu cpf/cnpj
#' @name tel
#'
#' @description Arruma seu cpf e cnpj para o padrao
#'
#' @param x as character
#' 
#' @return cpf/cnpj padrao 11/14 dig com zero na frente
#'
#' @author Jonatas Ribeiro
#' @importbase ifelse, nchar, as.character, paste0, substr, gsub
#' @export

tel <- function(tel,x = "0"){
  
  if (nchar(tel) > 11) {
    if (substring(gsub("[^0-9]", "", tel),nchar(gsub("[^0-9]", "", tel))-(8 + nchar(x)),
                  nchar(gsub("[^0-9]", "", tel))-9) == x) {
      paste0(substring(gsub("[^0-9]", "", tel),nchar(gsub("[^0-9]", "", tel))-(10 + nchar(x)),
                       nchar(gsub("[^0-9]", "", tel))-(9 + nchar(x))),
             substring(gsub("[^0-9]", "", tel),nchar(gsub("[^0-9]", "", tel))-8,
                       nchar(gsub("[^0-9]", "", tel))))
    } else {
      tel = as.character(ifelse(nchar(tel)>11,
                                 substring(gsub("[^0-9]", "", tel),nchar(gsub("[^0-9]", "", tel))-10,
                                           nchar(gsub("[^0-9]", "", tel))),
                                 gsub("[^0-9]", "", tel)))
      
      tel = ifelse(substring(gsub("[^0-9]", "", tel),1,1) == '0',
                   substring(gsub("[^0-9]", "", tel),nchar(gsub("[^0-9]", "", tel))-9,nchar(gsub("[^0-9]", "", tel))),
                   gsub("[^0-9]", "", tel))
      tel 
    }
    
  }

}
