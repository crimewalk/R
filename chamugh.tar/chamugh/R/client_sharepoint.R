#' @title Func 
#' @name client_shrp
#'
#' @description Devolve infos da api
#'
#' @return database
#'
#' @author Jonatas Ribeiro
#' @export
#' 

client_shrp <- function(site){
  if (site == "https://paschoalotto.sharepoint.com/sites/CuradoriaPlus") {
    client_id = " f9026d8a-aca9-4742-90cd-93ddb6d880ca@1de5ae7d-2e25-49b4-b8c0-e28ffe53080a" 
    client_secret = " YBa1fOfQZoVGV1VLJEChKJd/NPLTwghS73CxMkfosKk="
    resource = " 00000003-0000-0ff1-ce00-000000000000/paschoalotto.sharepoint.com@1de5ae7d-2e25-49b4-b8c0-e28ffe53080a"
  } else   if (site == "https://paschoalotto.sharepoint.com/sites/AC2") {
    client_id = " 7cb8f140-2bf6-47c2-a9e8-b756047a0801@1de5ae7d-2e25-49b4-b8c0-e28ffe53080a"
    client_secret = " rDWi8FlGDhMjTTw2TrAlHWzdBRx9KO+2B9YNZe7rvoQ="
    resource = " 00000003-0000-0ff1-ce00-000000000000/paschoalotto.sharepoint.com@1de5ae7d-2e25-49b4-b8c0-e28ffe53080a"
  }
  return(list("client_id" = client_id,"client_secret"=client_secret,"resource"=resource))
}
