#' @title Data automatica Curadoria
#' @name du
#'
#' @description Caso seja enviado alguma solicitacao via goat, retorna data desejada
#'
#' @return data de execucao
#' 
#' @param dias A string
#'
#' @author Victor
#' @importFromdata.table as.IDate, wday
#' @importFrombase list, paste0,data.frame,cumsum, substring, as.Date, months
#' @importFromdplyr mutate
#' @importFromlubridate floor_date
#' 
#' @export
#' 

du <- function(dias){
  out.day <- c('-01-01','-04-01','-04-02','-04-21','-05-01','-09-07','-10-12','-11-02','-11-15','-12-25')
  dus <- data.frame()
  for (x in 1:length(dias)) {
    table.d <- base::data.frame(list(as.Date(paste0(substring(dias[x],1,8),"01")):as.Date(lubridate::floor_date(as.Date(dias[x]) %m+% months(1), 'month')-1)))
    colnames(table.d) <- 'datas'
    du <- dplyr::mutate(table.d,
                        Datas = data.table::as.IDate(datas),
                        d = ifelse(data.table::wday(Datas) %in% c(1,7),0,1),
                        d = ifelse(Datas %in% c(base::as.Date(paste0(substring(dias[x],1,4),out.day))),0,d),
                        du = cumsum(d),
                        d = NULL,
                        datas = NULL) %>% dplyr::filter(Datas %in% c(as.Date(dias[x])))
    dus <- rbind(dus,du)
  }
  dus$du
}