#' @title Divisor de bases
#' @name divisor_cl
#'
#' @description Salva arquivos com a quantidade de linhas desejadas, dividindo a base.
#' 
#' @param tbl A data.frame
#' @param n A string
#' @param nome A string
#' @param tipo A string
#'
#' @author Jonatas Ribeiro
#' @importFrombase as.character, paste0, as.data.frame, as.numeric, round, nrow, write.csv2
#' 
#' @export
#' 

divisor_cl <- function(tbl,n,nome = "divisor_cl_",tipo = "csv"){
  
  tbl = base::as.data.frame(tbl)
  n = base::as.numeric(n)
  nome = base::as.character(nome)
  tipo = base::as.character(tipo)
  a = 0
  
  for (x in 1:base::as.numeric(base::round(base::nrow(tbl)/n))) {
    base::write.csv2(tbl[a:(a+n),],base::paste0(nome,x,'.',tipo),quote = F,row.names = F,na = "")
    a = a+n
  }
  
}
