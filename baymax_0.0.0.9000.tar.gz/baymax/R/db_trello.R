#' @title Pegando os dados do quadro desejado.
#' @name db_trello
#'
#' @description Pegue a chave do quadro do trello, para extrair as infos e Convide o email curadoria*paschoalotto.com.br
#'
#' @return tabela do trello
#' 
#' @param key_quadro A string
#'
#' @author Jonatas Ribeiro
#' @importFromjsonlite fromJSON
#' @importFromhttr GET
#' @importFrombase as.character,paste0
#' 
#' @export
#' 

db_trello <- function(key_quadro){
  chavedaAPI="930e27f807c156df7130512f497851da"
  tokendaAP="6a130ac47f262d4acf013574b115ce6badf97ea461d4d36a4971690a2449891a"
  jsonlite::fromJSON(base::as.character(httr::GET(url = base::paste0("https://api.trello.com/1/boards/",
                                                                     base::as.character(key_quadro),
                                                                    "/cards?fields=all&key=",
                                                                    chavedaAPI,
                                                                    "&token=",
                                                                    tokendaAP)),encode = "form"), flatten = TRUE)
}
